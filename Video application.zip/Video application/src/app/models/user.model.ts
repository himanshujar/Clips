export default interface IUser {
  email: string,
  password?: string,
  age: number,
  name: string,
  phoneNumber: string
}