describe('App Component', () => {
  it('should pass sanity test', () => {
    expect(true).toBeTruthy();
  });
});
