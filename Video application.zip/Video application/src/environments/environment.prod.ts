export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyASCxHgCSpmVnQwVbLCHATcns5fJQFdmpY",
    authDomain: "clips-36548.firebaseapp.com",
    projectId: "clips-36548",
    storageBucket: "clips-36548.appspot.com",
    appId: "1:798864185458:web:f93bd21de7f956bffc4aeb"
  }
};
